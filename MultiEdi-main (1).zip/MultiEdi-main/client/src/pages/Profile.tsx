import { UserInfo } from "@/components/UserInfo";

export default function Profile() {
  return <UserInfo />;
}
